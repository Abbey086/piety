package xyz.amandainc.piety;

import android.content.Context;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.app.*;

public class WebAppInterface {
    Context mContext;

    // Constructor
    WebAppInterface(Context context) {
        mContext = context;
    }

    // Example function: show toast
    @JavascriptInterface
    public void showToast(String message) {
        Toast.makeText(mContext, message, Toast.LENGTH_LONG).show();
    }

    // Another example: trigger some event
    @JavascriptInterface
    public String getAppName() {
        return "hello";
    }
}
