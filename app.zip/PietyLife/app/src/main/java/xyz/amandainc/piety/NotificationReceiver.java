package xyz.amandainc.piety;

import android.app.*;
import android.content.*;
import android.os.*;

public class NotificationReceiver extends BroadcastReceiver {
    @Override
	public void onReceive(Context context, Intent intent) {
		String[][] notifications = {
			{"Win Today", "Log your habit now. Every small win leads to lasting change."},
			{"Peace of Mind Is One Tap Away", "Ensure your notes and prayers are saved. Back up today."},
			{"Prayer Unrecorded Is Easily Forgotten", "Note your prayer today to witness God’s response tomorrow."},
			{"Fuel the Mission", "Every small gift supports the app and helps reach more believers."},
			{"Capture Today’s Thoughts", "Write a note before the day ends — don’t let inspiration fade."},
			{"Your Streak Needs You", "Don’t break it now — open and track your habits today."},
			{"Stay Rooted in Scripture", "Your Bible plan awaits — continue your journey."},
			{"A Daily Habit of Faith", "Your progress record is proof of God’s work in you."},
			{"Don’t Lose Your Progress", "Backup now and keep your journey protected."},
			{"Stay Consistent in Prayer", "Track today’s prayer and strengthen your relationship with God."},
			{"One Verse Can Change Your Day", "Read today’s passage now and carry it with you."},
			{"Be Part of Something Bigger", "Support the app today — together we spread the Word further."},
			{"One Small Habit, Big Growth", "Complete today’s habit to strengthen tomorrow’s discipline."},
			{"Your Data Matters", "Tap to back up your faith records — never lose your testimony."},
			{"Feed Your Spirit", "Open today’s scripture and be refreshed in the Word."},
			{"What Did You Pray For Today?", "Record it now — see how faithfully God answers."},
			{"Your Journey Needs Your Words", "Write today, so you can look back tomorrow and see God’s hand."},
			{"Keep the Light Shining", "Donating helps this app grow and touch more lives around the world."},
			{"Another Step Forward", "Mark today’s habit and move closer to your spiritual goals."},
			{"One Minute to Reflect", "Take a moment to note today’s blessings and lessons."},
			{"Secure Your Journey", "Back up your notes, prayers, and habits to keep them safe."},
			{"Your Prayer Journal Awaits", "Don’t miss a day — log your prayers before it slips your mind."},
			{"Your Bible Reading Awaits", "Don’t miss out — today’s chapter is waiting for you."},
			{"Consistency Builds Faith", "Take 2 minutes to record today. Tomorrow you’ll be glad you did."},
			{"Jot It Down", "God speaks in whispers; record what’s on your heart right now."},
			{"Keep Your Journal Alive", "Your daily notes tell the story of your walk with Christ."},
			{"Stay on Track", "Tick off today’s habit and keep your streak alive."},
			{"Your Support Matters", "Give today — help us build and expand this app’s impact."},
			{"Lift Your Heart in Prayer", "Don’t forget to record your prayer request or thanksgiving today."},
			{"Keep Your Legacy Safe", "Secure your walk with Christ by backing up your records now."},
			{"Daily Bread for Today", "Spend a moment in the Word. A verse today brings light."}
		};
		String channelId = "daily_channel";
		NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			NotificationChannel channel = new NotificationChannel(
				channelId, "Daily Notifications", NotificationManager.IMPORTANCE_HIGH
			);
			manager.createNotificationChannel(channel);
		}

		// 👉 Create intent to open MainActivity when clicked
		Intent launchIntent = new Intent(context, MainActivity.class);
		launchIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

		PendingIntent pendingLaunch = PendingIntent.getActivity(
			context, 0, launchIntent,
			PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
		);
		int day = Integer.parseInt(new java.text.SimpleDateFormat("d").format(new java.util.Date()));
		Notification.Builder builder = new Notification.Builder(context)
            .setContentTitle(notifications[day][0])
            .setContentText(notifications[day][1])
			
            .setSmallIcon(R.drawable.notify_icon) // your custom icon
            .setContentIntent(pendingLaunch) // 👈 set the click action
            .setAutoCancel(true); // dismiss when clicked

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			builder.setChannelId(channelId);
		}

		manager.notify(2001, builder.build());

		// 🔁 Reschedule for tomorrow
		MainActivity.scheduleDailyNotification(context);
	}
}
