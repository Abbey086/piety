package xyz.amandainc.piety;

import android.*;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
	private WebView webView;
    private View splashScreen;
	private boolean s = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
							 WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		
		Window window = getWindow();
		window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
		window.setStatusBarColor(Color.parseColor("#F2F2F7")); // white status bar
		window.setNavigationBarColor(Color.parseColor("#F2F2F7")); // to match status bar
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
				requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
			}
		}
// Set dark icons depending on Android version
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
			// Android 11+ (API 30+) - use WindowInsetsController
			WindowInsetsController insetsController = window.getInsetsController();
			if (insetsController != null) {
				insetsController.setSystemBarsAppearance(
					WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS,
					WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
				);
			}
		} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			// Android 6.0 to Android 10 (API 23 to 29)
			View decor = window.getDecorView();
			decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		}
		
		    webView = findViewById(R.id.webView);
        splashScreen = findViewById(R.id.splashScreen);

        // WebView configuration
        webView.getSettings().setJavaScriptEnabled(true);
		webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());    // Prevent opening browser
        webView.setWebChromeClient(new WebChromeClient());
		webView.addJavascriptInterface(new WebAppInterface(this), "Android");
       
        	webView.loadUrl("file:///android_asset/app/dashboard.html");
		
			//

        // Hide splash when page finishes loading
        webView.setWebViewClient(new WebViewClient() {
				@Override
				public void onPageFinished(WebView view, String url) {
					// Delay 5 seconds before starting the slide-out
					if(s){
						s=false;
					new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
							@Override
							public void run() {
								Animation slideOut = AnimationUtils.loadAnimation(MainActivity.this, R.anim.slide);
								slideOut.setAnimationListener(new Animation.AnimationListener() {
										@Override
										public void onAnimationStart(Animation animation) {}

										@Override
										public void onAnimationEnd(Animation animation) {
											splashScreen.setVisibility(View.GONE);
										}

										@Override
										public void onAnimationRepeat(Animation animation) {}
									});

								splashScreen.startAnimation(slideOut);
								getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

							}
						}, 5000); }// 5-second delay

				}
				
			});
		
			
		webView.setDownloadListener(new DownloadListener() {
				@Override
				public void onDownloadStart(String url, String userAgent,
											String contentDisposition, String mimetype,
											long contentLength) {
					// Handle the download here
					DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
					request.setMimeType(mimetype);

					// Show file in notification after download
					request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

					// Set destination
					request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, 
															  URLUtil.guessFileName(url, contentDisposition, mimetype));

					// Enqueue download
					DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
					dm.enqueue(request);

					Toast.makeText(getApplicationContext(), "Downloading File...", Toast.LENGTH_LONG).show();
				}
			});
		
		scheduleDailyNotification(this);
		// Schedule notification at 6:40 PM every day
		// 🔔 TEST NOTIFICATION: fire 30 seconds after app opens
		Calendar testCal = Calendar.getInstance();
		testCal.add(Calendar.SECOND, 30); // 30 seconds from now

		Intent testIntent = new Intent(this, NotificationReceiver.class);
		PendingIntent testPending = PendingIntent.getBroadcast(
			this, 1, testIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
		);

		AlarmManager testAlarm = (AlarmManager) getSystemService(ALARM_SERVICE);
		if (testAlarm != null) {
			testAlarm.setExactAndAllowWhileIdle(
				AlarmManager.RTC_WAKEUP,
				testCal.getTimeInMillis(),
				testPending
			);
		}
    }
	
	public static void scheduleDailyNotification(Context context) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 19); // 6 PM
		calendar.set(Calendar.MINUTE, 17);
		calendar.set(Calendar.SECOND, 0);

		// If time already passed, schedule for tomorrow
		if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
			calendar.add(Calendar.DAY_OF_MONTH, 1);
		}

		Intent intent = new Intent(context, NotificationReceiver.class);
		PendingIntent pendingIntent = PendingIntent.getBroadcast(
			context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
		);

		AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
		if (alarmManager != null) {
			alarmManager.setExactAndAllowWhileIdle(
				AlarmManager.RTC_WAKEUP,
				calendar.getTimeInMillis(),
				pendingIntent
			);
		}
	}

	@Override
	public void onBackPressed()
	{
		// TODO: Implement this method
		webView.evaluateJavascript("back('Fred');", null);
		
	}
	
}
